# the url of the web server whit directory listing
serveurURL = "http://oxproject.fr.nf:8000/"
# name of installer window
windowname = "OXipro launcher"
# text of first text lable in GUI
windowlabletitle = "OXipro's launcher"
# name of the installer window icon default is oxiprosinstaller.png
windowiconame = "installer.png"
